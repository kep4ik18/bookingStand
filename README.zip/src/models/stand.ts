export enum StandTypeEnum {
  HIL = "HIL",
  ERTI = "ERTI",
}
