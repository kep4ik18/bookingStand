import { Stack, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import { useGetAgentsListQuery } from "../../store/service/test/service";
import { standTypeSelector } from "../../store/slices/application-filter-slice/selectors";

export const MainPage = () => {
  const standType = useSelector(standTypeSelector);

  const { data } = useGetAgentsListQuery();
  console.log("data", data);

  return (
    <Stack>
      <Typography>Список заявок на бронирование</Typography>
      <Typography>{standType}</Typography>
    </Stack>
  );
};
